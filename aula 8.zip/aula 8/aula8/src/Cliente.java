public class Cliente extends Pessoa {
    private float valorDivida;

    public Cliente() {
    }

public Cliente(String n, String f, float v){
    super(n,f);
    valorDivida = v;
}


    public float getValorDivida() {
        return valorDivida;
    }

    public void setValorDivida(float valorDivida) {
        this.valorDivida = valorDivida;
    }
    public void print(){
        System.out.println("******************");
        System.out.println("Nome"+ getNome()+"\n"+"Telefone:"+ getFone()+"\n" + "Valor da divida:"+valorDivida);
        System.out.println("********************");
    }
}
